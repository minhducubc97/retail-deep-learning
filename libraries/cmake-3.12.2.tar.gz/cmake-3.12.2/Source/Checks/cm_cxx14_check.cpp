#include <cstdio>
int main()
{
  return 0;
}
