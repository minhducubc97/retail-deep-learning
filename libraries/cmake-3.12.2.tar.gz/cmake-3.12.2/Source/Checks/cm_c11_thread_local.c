_Thread_local int i = 42;
int main(void)
{
  return 0;
}
